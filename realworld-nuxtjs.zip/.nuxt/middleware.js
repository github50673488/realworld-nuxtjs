const middleware = {}

middleware['authenticated'] = require('..\\middleware\\authenticated.js')
middleware['authenticated'] = middleware['authenticated'].default || middleware['authenticated']

middleware['not-authenticated'] = require('..\\middleware\\not-authenticated.js')
middleware['not-authenticated'] = middleware['not-authenticated'].default || middleware['not-authenticated']

export default middleware
